﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlane : MonoBehaviour
{
    private Rigidbody plane;

    // Start is called before the first frame update
    void Start()
    {
        plane = gameObject.GetComponent("Rigidbody") as Rigidbody;
    }

    // Update is called once per frame
    void Update()
    {
        //Get axis input
        //Horizontal movement
        float h = Input.GetAxis("Horizontal");

        //vertical movement
        float v = Input.GetAxis("Vertical");

        //Print axis values to console
        Debug.Log("Horizontal" + h + "Vertical" + v);

        //Transform axis into position for force
        Vector3 thePositionx;
        Vector3 thePositiony;
        
        if (h>0)
        {
            thePositionx = transform.TransformPoint(Vector3.right);
        }
        else if(h<0)
        {
            thePositionx = transform.TransformPoint(Vector3.left);
        }
        else
        {
            thePositionx = transform.TransformPoint(0,0,0);
        }

        if (v > 0)
        {
            thePositiony = transform.TransformPoint(Vector3.forward);
        }
        else if (v < 0)
        {
            thePositiony = transform.TransformPoint(Vector3.back);
        }
        else
        {
            thePositiony = transform.TransformPoint(0, 0, 0);
        }

        Vector3 theDirection = transform.TransformDirection(Vector3.down);

        plane.AddForceAtPosition(theDirection, thePositionx);
        plane.AddForceAtPosition(theDirection, thePositiony);

    }
}
